let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
┷┯ ☾ *INFO BOT* ☽
   ╽
   ┠❥ *Dibuat dengan javascript NodeJs
   ┠❥ *Rec: aa Irwan
   ┠❥ *Script: @irwan_x_yans
┯┷ 
┠❥ *Instagram: instagram.com/irwan_x_yans
┠❥ *Twitter: @irwanx_taa
┃
┷┯ ☾ *DONASI* ☽
   ╽
   ┠❥ *ketik .donasi
   ╿
┯┷ ☾ *xYaNz* ☽
`.trim(), m)
}
handler.help = ['info']
handler.tags = ['about']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

