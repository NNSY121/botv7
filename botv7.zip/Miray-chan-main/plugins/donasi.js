let handler = async m => m.reply(`
╭─「 Donasi 」
│ • Dana/ovo: [08882611841]
│ • Pulsa Smartfren: [08882611841]
│ 
│ 「 Chat OWNER 」
│ ❥ Ingin donasi?
│ ❥ Wa.me/628882611841
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['about']
handler.command = /^dona(te|si)$/i

module.exports = handler
